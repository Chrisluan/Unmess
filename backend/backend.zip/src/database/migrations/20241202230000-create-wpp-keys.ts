import { QueryInterface, DataTypes } from "sequelize";

module.exports = {
  up: async (queryInterface: QueryInterface) => {
    await queryInterface.createTable("WppKeys", {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
      },
      connectionId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
          model: "Whatsapps",
          key: "id"
        },
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
      },
      type: {
        type: DataTypes.STRING(191),
        allowNull: false
      },
      keyId: {
        type: DataTypes.STRING(191),
        allowNull: false
      },
      value: {
        type: DataTypes.STRING(191),
        allowNull: false
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: false
      }
    });

    await queryInterface.addIndex(
      "WppKeys",
      ["connectionId", "type", "keyId"],
      {
        unique: true,
        name: "wpp_keys_connection_type_key_unique"
      }
    );
  },

  down: (queryInterface: QueryInterface) => {
    return queryInterface.dropTable("WppKeys");
  }
};
